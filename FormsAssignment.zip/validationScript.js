    // JavaScript code for form validation
	// Prevent form from submitting
  let form = document.getElementById("myForm");

  form.addEventListener("submit", function(event){
    
    // Retrieve the input field value
    let input = document.getElementById("inputField");
    // Regular expression pattern for alphanumeric input
    let inputRegex = /^[a-zA-z0-9]+$/;
      
      // Check if the input value matches the pattern
    if (!inputRegex.test(input.value)){
      window.alert('Invalid Input');
      event.preventDefault();
    } else {
      window.alert('Good Input');
    }
      

        // Valid input: display confirmation and submit the form

        // Invalid input: display error message
  })